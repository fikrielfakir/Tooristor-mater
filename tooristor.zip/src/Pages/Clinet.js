import React from "react";
import ClientRoutes from "../routes/clinet-routes";

export default function Client(){
    return(
       <h1>Hello</h1>
    );
}