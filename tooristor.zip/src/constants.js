export const AUTH_TOKEN = 'auth-token';
export const LINKS_PER_PAGE = 5;
