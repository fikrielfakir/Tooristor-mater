export {
  default as AgentAccountSettingsPage,
} from './AccountSettings/AgentAccountSettingsPage';
export {
  default as AgentDetailsViewPage,
} from './AccountDetails/AgentDetailsViewPage';
