import React, { useState } from "react";
import { CREATE_PORDUCT  } from "../../../../components/GraphQL/Mutations";
import { useMutation ,gql} from "@apollo/client";
function AddProduct() {
  const [CreateProduct, { data, loading, error }] = useMutation(CREATE_PORDUCT );
  const [newForm, setNewForm] = useState({ name: '', type_id: '', shop_id: '', price: '', quantity: '', product_type: '', unit: '', in_stock: '', is_taxable: '', status: ''});
  if (loading) return 'Submitting...';
  if (error) return `Submission error! ${error.message}`;
  if (data) return console.log(data);
  //function for handle updates on the create product form
  const formUpdate = (event) => {
    setNewForm({...newForm, [event.target.name]: event.target.value})
  }
  // creates a new product and adds it to the selected category
  const handleCreateType = async () => {
    try{
      const CreateTypeMutation = await CreateProduct ({
        variables:{ "input":{
          sku: newForm.sku || null,
          name: newForm.name , 
          type_id: JSON.parse(newForm.type_id), 
          shop_id: newForm.shop_id, 
          price: JSON.parse(newForm.price), 
          quantity: JSON.parse(newForm.quantity),
          product_type:newForm.product_type,
          unit: newForm.unit ,
          in_stock: newForm.in_stock || true,
          is_taxable: newForm.is_taxable || false,
          status: newForm.status || "PUBLISH"

        
      }}
      })
      return CreateTypeMutation;
    } catch (e) {
      console.log(e);
    }
  }
  return (
    <div>

        <form onSubmit={handleCreateType}> 
          <input type="text" onChange={formUpdate} value={newForm.name} placeholder="Name" name="name"/>
          <select name="type_id" onChange={formUpdate}>
          <option ></option>
            <option value="7">Pharmacy ChamalV</option>
            <option value="8">Parampharmcy VI</option>
          </select>
          <select name="shop_id" onChange={formUpdate}>
            <option ></option>
            <option value="8">Pharmacy</option>
            <option value="9">parapharmacy</option>
          </select>
          <input type="text" onChange={formUpdate} value={newForm.price} placeholder="price" name="price"/>
          <input type="text" onChange={formUpdate} value={newForm.quantity} placeholder="quantity" name="quantity"/>
          <select name="product_type" onChange={formUpdate}>
          <option ></option>
            <option value="SIMPLE">Simple</option>
            <option value="VARIABLE">Variable</option>
          </select>
          <input type="text" onChange={formUpdate} value={newForm.unit} placeholder="unit" name="unit"/>
         
            <button type="submit">Create</button>
        </form>
      {/* Spreadsheet Labels */}
    </div>
  );
}
export default AddProduct;
