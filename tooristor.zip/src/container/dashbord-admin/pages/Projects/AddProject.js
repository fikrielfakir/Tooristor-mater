import React, { useState } from "react";
import { UPDATE_SHOP  } from "../../../../components/GraphQL/Mutations";
import { DELETE_SHOP  } from "../../../../components/GraphQL/Mutations";
import { CREATE_SHOP  } from "../../../../components/GraphQL/Mutations";
import { GET_SHOPS  } from "../../../../components/GraphQL/Queries";
import { useQuery, useMutation } from "@apollo/client";

function AdminProducts() {

  const [deleteShop] = useMutation(DELETE_SHOP);
  const [createShop] = useMutation(CREATE_SHOP);


  // sets state for new product form to false so it does not render on load up

  const [showForm, setShowForm] = useState(false);
  const [newForm, setNewForm] = useState({ name: '', price: '', cost: '', parStock: '', quantity: '', description: '', category: ''})
  // Display all products
  // iterates over the list of products and creates a link to the single product page
  //shows image, name, price, and add to cart button
  const [showModal, setShowModal] = useState(false);
  const [modalContent, setModalContent] = useState();

  const [updateShop] = useMutation(UPDATE_SHOP);

  let shopsList;
  const { loading, error, data } = useQuery(GET_SHOPS);
  if (loading) return "Loading...";
  if (error) return `Error! ${error.message}`;
  if (!loading && !error) {
    shopsList = data.Shops;
  }

  // allows admin to update the item information on the admin page 
  const handleUpdateShop = async(event) =>{
    event.preventDefault();
    try{
      const updatingRow = await updateShop({
        variables: { 
          id: modalContent.id,
          name: modalContent.name,
          
        },
      });
      return updatingRow;
    }
    catch(e){
      console.log(e);
    }
  };

  // function to populate the modal when you click on a line
  const setContent=(event)=>{
    // console.log(event.target.parentNode.dataset.index);
    // console.log(shopsList[event.target.parentNode.dataset.index]);
    setModalContent({...shopsList[event.target.parentNode.dataset.index]})
    modalTrigger();
 }

 // function to update the row info through the modal
  const modalUpdate = (event) =>{
    setModalContent({...modalContent, [event.target.name]: event.target.value})
    console.log('update---log');
}

// function to open/close the modal
  const modalTrigger = () => {
    if (showModal) {
      setShowModal(false);
    } else {
      setShowModal(true);
    }
  };
  // function to open and close to create product modal
  const openForm = () => {
    if (showForm) {
      setShowForm(false);
    } else {
      setShowForm(true);
    }
  };

  //function for handle updates on the create product form
  const formUpdate = (event) => {
    setNewForm({...newForm, [event.target.name]: event.target.value})
  }

  //function to confirm if user would like to delete product
  const deleteAlert = async (event) => {
    event.preventDefault();
    const clickID = event.target.id;
    console.log(clickID);
    let x = window.confirm("are you sure you want to delete this product?");
    if (x) {
      handledeleteShop(clickID);
    } else {
      return
    }
  }

  // function to delete the target product
  const handledeleteShop = async (clickID) => {
    try{
      const deleteMutation = await deleteShop ({
        variables: { id: clickID }
      });
      return deleteMutation;
    } catch (e) {
      console.log(e);
    }
    
  }

  // creates a new product and adds it to the selected category
  const handleCreateShop = async () => {
    try{
      const createShopMutation = await createShop ({
        variables: {
          name: newForm.name }
      })
      return createShopMutation;
    } catch (e) {
      console.log(e);
    }
  }




  return (
    <div>
      {showModal && (
        <form className="input-field" onSubmit={handleUpdateShop}> 
            <input  className="input-name" type="text" value={modalContent.name} onChange={modalUpdate} name="name"/>
            <button type="submit">SAVE</button>
            <span onClick={modalTrigger}>
              CLOSE
            </span>

        </form>
      )}
      {showForm && (
        <form className="input-field" onSubmit={handleCreateShop}> 
            <input  className="input-name" type="text" value={newForm.name} onChange={formUpdate} name="name" placeholder="name"/>
            <button type="submit">Create</button>
            <span onClick={openForm}>
              Cancel
            </span>

        </form>
      )}
      {/* Spreadsheet Labels */}
      <div className="admin-product">
        <div className="admin-product-list">
          <h3 className="admin-product-item admin-product-item-label">Name</h3>
          <h3
            className="admin-product-item admin-product-item-label"
            id="addProduct" onClick={openForm}
          >
            +
          </h3>
        </div>
        {/* Spreadsheet content  */}
        {shopsList.data.map((shop, index) => {
          return (
            <div className="admin-product-list" key={shop.id} data-index={index} >
              <p className="admin-product-item" id="productname" onClick={setContent}>
                {shop.name}
              </p>
              <p className="admin-product-item" id={shop.id} onClick={deleteAlert}>
                X
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default AdminProducts;
