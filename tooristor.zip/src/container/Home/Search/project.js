import * as React from 'react';
import Citys from './ma.json'


function projet(props) {
  return (
    <>
   <select className="col-sm">
      <option value="1">pharmacy</option>
      <option value="1">parapharmacy</option>
      <option value="1">clothes</option>
    </select>
    </>
    
    );
}
export default projet;