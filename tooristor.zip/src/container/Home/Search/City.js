import * as React from 'react';
import Citys from './ma.json'


function City(props) {
  return (
    <>
   <select className="col-sm">
      <option value="1">Casbalnca</option>
      <option value="1">Al hoceima</option>
      <option value="1">Tanger</option>
    </select>
    </>
    
    );
}
export default City;