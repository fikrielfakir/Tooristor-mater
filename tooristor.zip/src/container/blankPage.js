import React, { Fragment } from 'react';

const BlankPage = props => {
  return <Fragment>{props.children}</Fragment>;
};

export default BlankPage;
