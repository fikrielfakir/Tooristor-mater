import { gql } from "@apollo/client";
export const GET_PRODUCTS = gql`
 query Products(
  $orderBy: [QueryProductsOrderByOrderByClause!]
  $text: String
  $status: String
  $shop_id: Int
  $hasType: QueryProductsHasTypeWhereHasConditions
  $hasCategories: QueryProductsHasCategoriesWhereHasConditions
  $first: Int
  $page: Int
) {
  products(
    orderBy: $orderBy
    text: $text
    status: $status
    hasType: $hasType
    hasCategories: $hasCategories
    first: $first
    page: $page
    shop_id: $shop_id
  ) {
    data {
      id
      sku
      slug
      name
      description
      image {
        id
        thumbnail
        original
      }
      type {
        id
        name
      }
      shop {
        name
      }
      price
      min_price
      max_price
      quantity
      product_type
      unit
      gallery {
        id
        thumbnail
        original
      }
      status
    }
    paginatorInfo {
      ...PaginatorParts
    }
  }
}
`;

export const GET_PRODUCT_DETAILS = gql`
query Product($id: ID, $slug: String) {
  product(id: $id, slug: $slug) {
    id
    sku
    shop_id
    slug
    name
    description
    image {
      id
      thumbnail
      original
    }
    in_stock
    sale_price
    price
    min_price
    max_price
    quantity
    unit
    height
    width
    length
    status
    gallery {
      id
      thumbnail
      original
    }
    categories {
      id
      icon
      name
      slug
    }
    tags {
      id
      name
      slug
    }
    type {
      id
      name
      slug
    }
    product_type
    variations {
      id
      value
      attribute {
        name
        slug
        values {
          id
          value
        }
      }
      # pivot {
      #   price
      # }
    }
    variation_options {
      id
      sku
      title
      price
      quantity
      is_disable
      sale_price
      options {
        name
        value
      }
    }
  }
  # attributes {
  #   id
  #   name
  #   slug
  #   values {
  #     id
  #     value
  #   }
  # }
}
`;
export const GET_CATEGORY = gql`
query{
  categories {
    data {
      id
      name
    }
  }
}
`;
export const GET_SHOPS = gql`
query Shops(
  $text: String
  $orderBy: String
  $sortedBy: String
  $first: Int = 15
  $page: Int
  $is_active: Boolean
) {
  shops(
    first: $first
    page: $page
    text: $text
    orderBy: $orderBy
    is_active: $is_active
    sortedBy: $sortedBy
  ) {
    data {
      ...ShopParts
    }
    paginatorInfo {
      ...PaginatorParts
    }
  }
}
${GET_SHOP_PARTS}
`;
const GET_SHOP_PARTS = gql`
fragment ShopParts on Shop {
  id
  name
  slug
  owner_id
  owner {
    name
    email
    profile {
      contact
    }
  }
  staffs {
    name
    email
  }
  description
  logo {
    id
    thumbnail
    original
  }
  cover_image {
    id
    thumbnail
    original
  }
  orders_count
  products_count
  is_active
  balance {
    admin_commission_rate
    total_earnings
    withdrawn_amount
    current_balance
    payment_info {
      account
      name
      bank
      email
    }
  }
  address {
    street_address
    country
    city
    state
    zip
  }
  created_at
}
`;

