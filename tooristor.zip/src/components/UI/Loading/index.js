import React from "react"

const Loading = () =>{
<div className="loading">
          
<div class="loadingio-spinner-spinner-fxblu79ew5g"><div class="ldio-cvywdoy3t2n">
<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>
</div></div>


        <p>Please wait...</p>
      </div>};
      export default Loading