export const isServer = typeof window === 'undefined';
